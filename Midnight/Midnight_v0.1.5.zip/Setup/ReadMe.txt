//If You Claim You Cracked This Do The Following And Kill Yourself.
//Most Source Is Open Source But Has Been Repaired With The Obfued Namespace
//And Pidgon If Your Reading This Get Fucked - _Sever#0001

Midnight Devs
_Sever/Exploit
RABBIX
sachiel.J 

Helpers
Ikari No Kami
PC Prinipal
Umbra - Fade Away
The Server Queer
